/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Virtual function table layout of superclass.  */
#include "ostream.vt.h"

/* Virtual function table layout of styled_ostream class.  */
         void (*begin_use_class) (THIS_ARG, const char *classname);
         void (*end_use_class) (THIS_ARG, const char *classname);
             void (*flush_to_current_style) (THIS_ARG);
