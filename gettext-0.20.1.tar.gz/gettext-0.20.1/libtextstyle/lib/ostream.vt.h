/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Virtual function table layout of ostream class.  */
       void (*write_mem) (THIS_ARG, const void *data, size_t len);
        void (*flush) (THIS_ARG, ostream_flush_scope_t scope);
        void (*free) (THIS_ARG);
