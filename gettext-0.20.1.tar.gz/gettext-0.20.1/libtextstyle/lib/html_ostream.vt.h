/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Virtual function table layout of superclass.  */
#include "ostream.vt.h"

/* Virtual function table layout of html_ostream class.  */
         void (*begin_span) (THIS_ARG, const char *classname);
         void (*end_span) (THIS_ARG, const char *classname);
             void (*flush_to_current_style) (THIS_ARG);
