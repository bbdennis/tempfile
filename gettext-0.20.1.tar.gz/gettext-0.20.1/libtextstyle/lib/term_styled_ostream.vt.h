/* DO NOT EDIT! GENERATED AUTOMATICALLY! */

/* Virtual function table layout of superclass.  */
#include "styled_ostream.vt.h"

/* Virtual function table layout of term_styled_ostream class.  */
