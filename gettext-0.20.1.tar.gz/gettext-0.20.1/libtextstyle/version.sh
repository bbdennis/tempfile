# Version number and release date.
VERSION_NUMBER=0.20
RELEASE_DATE=2019-05-08      # in "date +%Y-%m-%d" format
